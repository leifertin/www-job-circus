-- MySQL dump 10.13  Distrib 5.5.45, for Linux (x86_64)
--
-- Host: localhost    Database: JobPool
-- ------------------------------------------------------
-- Server version	5.5.45-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Coupons`
--

DROP TABLE IF EXISTS `Coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Coupons` (
  `couponID` int(11) NOT NULL AUTO_INCREMENT,
  `couponCode` varchar(14) NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`couponID`),
  UNIQUE KEY `couponID` (`couponID`),
  UNIQUE KEY `couponCode` (`couponCode`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Coupons`
--

LOCK TABLES `Coupons` WRITE;
/*!40000 ALTER TABLE `Coupons` DISABLE KEYS */;
INSERT INTO `Coupons` (`couponID`, `couponCode`, `postingDate`) VALUES (1,'ZV53ES7NQFDAXR','2015-11-09 03:15:47'),(2,'U83FDFQ6ZW0JSZ','2015-11-09 03:16:36'),(3,'8ZQNKEVB7AD6VF','2015-11-09 03:21:21'),(4,'Z2836R4Z4V9SDS','2015-11-09 03:23:40'),(5,'866TV37GAQFPEA','2015-11-09 03:27:51'),(6,'TMNN2MDEVWCSTW','2015-11-09 03:30:17'),(7,'KA17ADCDHG8NCM','2015-11-09 03:32:02'),(8,'KR27V97TR3LLCR','2015-11-09 03:34:22'),(9,'D9K8ZC92DG23RG','2015-11-09 03:36:01'),(10,'KKD8J2QN8JMSPZ','2015-11-09 03:37:54'),(11,'GDSZSEN7ZK9GAC','2015-11-09 03:39:08'),(12,'2WJNW3R4K8PRC4','2015-11-09 03:41:09'),(13,'AMYPYGDWRPYSCL','2015-11-09 03:42:27'),(14,'89RA6QGNX4ZJX6','2015-11-09 03:43:53'),(15,'J27EH6PTKQSN6V','2015-11-09 03:46:02'),(16,'NNTRV2L4C7LFM2','2015-11-09 03:47:39'),(17,'4WKP6LK2AVXG7X','2015-11-09 03:49:10'),(18,'RANGRJCLP9DXXS','2015-11-09 04:14:19'),(19,'Z3WHPDNLWFQGLW','2015-11-09 04:16:44'),(20,'XMLV4RF939W8AD','2015-11-09 04:18:09'),(21,'EL297WFW6S6YSH','2015-11-09 04:19:41'),(22,'N9F2LAZ68ED3MR','2015-11-09 04:21:07'),(23,'M3DSKJ9NL7CZ29','2015-11-09 04:22:14'),(25,'7CMZTSXFXSPNTF','2015-11-09 04:24:39'),(26,'Y3SXN4JTLEZFZ4','2015-11-09 04:25:47'),(27,'TS2288ECVMTNN8','2015-11-09 04:27:00'),(28,'W8H7TSSKPVADY4','2015-11-09 04:28:07'),(29,'F3VGP3CX9H7JTN','2015-11-09 04:29:15'),(30,'ZHSTYRGY9DD8TH','2015-11-09 04:31:36'),(31,'4RRCL6Y7CAYSSZ','2015-11-09 21:23:01'),(32,'9A8AL3MMY3A6RE','2015-11-09 21:24:18'),(33,'JYKNLGMXKMTF8W','2015-11-09 21:25:42'),(34,'GSVR9FJEJW98Z3','2015-11-09 21:26:52'),(35,'W2NZZRXPXEXQ8Y','2015-11-09 21:28:26'),(36,'Z2G2DC8E2VAKWY','2015-11-09 21:29:48'),(37,'LD3DXFTMY7EE8C','2015-11-09 21:31:27'),(38,'X8NYWXDVXQKW9P','2015-11-09 21:33:00'),(39,'58B4449DAA3323','2015-11-21 02:36:27'),(40,'01234567891021','2015-11-21 02:36:45');
/*!40000 ALTER TABLE `Coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employers`
--

DROP TABLE IF EXISTS `Employers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employers` (
  `employerID` int(11) NOT NULL AUTO_INCREMENT,
  `businessName` varchar(60) CHARACTER SET utf8 NOT NULL,
  `genre` varchar(50) CHARACTER SET utf8 NOT NULL,
  `address` varchar(95) CHARACTER SET utf8 NOT NULL,
  `city` varchar(45) CHARACTER SET utf8 NOT NULL,
  `state` varchar(33) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(12) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `loginData` varchar(60) COLLATE utf8_bin NOT NULL,
  `emailverify` varchar(42) COLLATE utf8_bin NOT NULL,
  `confirmed` varchar(3) CHARACTER SET utf8 NOT NULL DEFAULT 'no',
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `numJobs` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`employerID`),
  UNIQUE KEY `employerID` (`employerID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employers`
--

LOCK TABLES `Employers` WRITE;
/*!40000 ALTER TABLE `Employers` DISABLE KEYS */;
INSERT INTO `Employers` (`employerID`, `businessName`, `genre`, `address`, `city`, `state`, `phone`, `email`, `loginData`, `emailverify`, `confirmed`, `postingDate`, `numJobs`) VALUES (3,'steve heflin plumbing','Repair','South Asheville','Asheville','North Carolina','828-776-0399','sheflin0616@gmail.com','8dbcdc27cc061b7d58ce4be350c31bf9597e9d82','77b52fd051e7a8c513ac3538d3fbe03f92bdecd1','yes','2015-12-18 13:01:28',1);
/*!40000 ALTER TABLE `Employers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs`
--

DROP TABLE IF EXISTS `Jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs` (
  `postingID` int(11) NOT NULL AUTO_INCREMENT,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pay` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT 'no',
  `employerID` int(11) NOT NULL,
  `businessName` varchar(60) CHARACTER SET utf8 NOT NULL,
  `position` varchar(90) CHARACTER SET utf8 NOT NULL,
  `genre` varchar(70) CHARACTER SET utf8 NOT NULL,
  `wage` decimal(6,2) NOT NULL,
  `tips` varchar(1) CHARACTER SET utf8 NOT NULL,
  `responsible` varchar(500) CHARACTER SET utf8 NOT NULL,
  `qualify` varchar(450) CHARACTER SET utf8 NOT NULL,
  `comments` varchar(350) CHARACTER SET utf8 NOT NULL,
  `applicantIDs` text CHARACTER SET utf8 NOT NULL,
  `city` varchar(45) CHARACTER SET utf8 NOT NULL,
  `state` varchar(33) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`postingID`),
  UNIQUE KEY `postingID` (`postingID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs`
--

LOCK TABLES `Jobs` WRITE;
/*!40000 ALTER TABLE `Jobs` DISABLE KEYS */;
INSERT INTO `Jobs` (`postingID`, `postingDate`, `pay`, `employerID`, `businessName`, `position`, `genre`, `wage`, `tips`, `responsible`, `qualify`, `comments`, `applicantIDs`, `city`, `state`) VALUES (1,'2015-11-23 01:14:41','yes',3,'steve heflin plumbing','plumbers helper','Repair',12.00,'','assisting in plumbing/home repairs','prior exp. in repair/ plumbing/ construction helpful.','this is part time. 12.00-15.00 depending on exp.',',1,7,','Asheville','North Carolina');
/*!40000 ALTER TABLE `Jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `txn_id` varchar(19) NOT NULL,
  `payer_email` varchar(75) NOT NULL,
  `mc_gross` float(9,2) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `txn_id` (`txn_id`),
  UNIQUE KEY `order_id` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Orders`
--

LOCK TABLES `Orders` WRITE;
/*!40000 ALTER TABLE `Orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `Orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Session`
--

DROP TABLE IF EXISTS `Session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Session` (
  `sessionID` varchar(42) COLLATE utf8_bin NOT NULL,
  `userID` int(11) NOT NULL,
  `userType` varchar(1) COLLATE utf8_bin NOT NULL,
  `started` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sessionID`),
  UNIQUE KEY `sessionID` (`sessionID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Session`
--

LOCK TABLES `Session` WRITE;
/*!40000 ALTER TABLE `Session` DISABLE KEYS */;
INSERT INTO `Session` (`sessionID`, `userID`, `userType`, `started`) VALUES ('9ac7993bf8b4a3398a85afbbbe3971dcf7bae018',1,'w','2015-12-19 21:56:15'),('1215da0a325096f3cf15f1e0ea37530af1028081',3,'e','2015-12-18 13:03:02'),('4eadd44ab290b7eb0ffe975c96e8f22f7426d132',1,'w','2015-12-19 22:47:22');
/*!40000 ALTER TABLE `Session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Workers`
--

DROP TABLE IF EXISTS `Workers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Workers` (
  `workerID` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `city` varchar(45) NOT NULL,
  `email` varchar(255) NOT NULL,
  `emailverify` varchar(42) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `confirmed` varchar(3) NOT NULL DEFAULT 'no',
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `loginData` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `phone` varchar(12) NOT NULL,
  `state` varchar(33) NOT NULL,
  `describeYourself` varchar(550) NOT NULL,
  `legalWork` varchar(3) NOT NULL,
  `transpt` varchar(3) NOT NULL,
  `available` varchar(2) NOT NULL,
  `applyTo` text NOT NULL,
  PRIMARY KEY (`workerID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `workerID` (`workerID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Workers`
--

LOCK TABLES `Workers` WRITE;
/*!40000 ALTER TABLE `Workers` DISABLE KEYS */;
INSERT INTO `Workers` (`workerID`, `firstname`, `lastname`, `city`, `email`, `emailverify`, `confirmed`, `postingDate`, `loginData`, `phone`, `state`, `describeYourself`, `legalWork`, `transpt`, `available`, `applyTo`) VALUES (1,'Leif','Heflin','Asheville','leifh90@gmail.com','73d8916641e773d47c9bd9d2ecad13a6ba5c977c','yes','2015-11-09 01:43:40','0b4d2281eb49b925f55dc1745d53ee7d084ffc3c','828-582-0865','North Carolina','Avid software engineer with an interest in languages.\r\nCompetent worker who always comes in on time and rarely calls out.','yes','yes','01',',3,'),(2,'kristin','fellows','Asheville','kristin@kristinfellows.com','2c58529fe5cf3bd59a5df4d3bf070c6e6c8912fc','yes','2015-11-05 16:58:24','80bbae8590fff41f4d2052453d00ca167e7f762c','828-335-6525','North Carolina','freelance photographer looking for creative photography gigs ~ street photography, day-in-the-life, and hikers in their habitats are specialties','yes','yes','11',','),(3,'John','Smith','Asheville','doiq316@gmail.com','9e56bbb9cf1d28325c843e1cb','yes','2015-11-10 16:04:51','e6e739b96364ed3fa972110ea7fc1ad7ef53e120','518-618-2539','North Carolina','Hey','yes','yes','10',','),(4,'Marjorie','Fox','Weaverville','mlfox78@charter.net','22894aa86f28069c298c0923e','yes','2015-11-21 15:45:38','9b4ea788d9745d4db6c032089711e3924a525278','8284848415','North Carolina','Experience in books, cashiering, hospital nutrition, \r\nclient services veterinary','yes','yes','10',','),(5,'nan','davis','Asheville','nsdasheville@gmail.com','fa4fcde44f2cf919ad913b124','yes','2015-11-23 01:21:40','09e2fbbafeea8aa28bbb899851b0f9251847da73','8287762318','North Carolina','creative, go getter','yes','yes','10',','),(6,'Melissa','Wood','Waynesville','woodmf09@bonaventure.edu','72db0920b482f65dc3019a3a2','yes','2015-11-23 15:21:56','10ea1602d510daf7118ad5fd8da88d745fae5cb4','7166978713','North Carolina','I am a goal-oriented young professional, dedicated to high levels of customer satisfaction and to meeting business goals, seeking to expand my knowledge of the public relations industry, but also possessing an abundance of experience in the retail industry. ','yes','yes','10',','),(7,'Jeremy','Scott','Asheville ','jeremyrscott480@gmail.com','ce9d79ceaa8a1ecccd491733e','yes','2015-12-18 06:08:53','25218c2778062ed5201b273811ef7bf1d74148df','331-223-8270','North Carolina','Former assistant property manger looking for work.','yes','no','11',',3,');
/*!40000 ALTER TABLE `Workers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkersJobHistory`
--

DROP TABLE IF EXISTS `WorkersJobHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkersJobHistory` (
  `workExperienceID` int(11) NOT NULL AUTO_INCREMENT,
  `workerID` int(11) NOT NULL,
  `fromMonth` varchar(2) NOT NULL,
  `fromYear` varchar(4) NOT NULL,
  `toMonth` varchar(2) NOT NULL,
  `toYear` varchar(4) NOT NULL,
  `employer` varchar(60) NOT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(33) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `position` varchar(90) NOT NULL,
  `responsible` varchar(400) NOT NULL,
  `reasonLeaving` varchar(250) NOT NULL,
  `comments` varchar(350) NOT NULL,
  `genre` varchar(70) NOT NULL,
  `current` varchar(1) NOT NULL,
  PRIMARY KEY (`workExperienceID`),
  KEY `toMonth` (`toMonth`,`toYear`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkersJobHistory`
--

LOCK TABLES `WorkersJobHistory` WRITE;
/*!40000 ALTER TABLE `WorkersJobHistory` DISABLE KEYS */;
INSERT INTO `WorkersJobHistory` (`workExperienceID`, `workerID`, `fromMonth`, `fromYear`, `toMonth`, `toYear`, `employer`, `city`, `state`, `phone`, `position`, `responsible`, `reasonLeaving`, `comments`, `genre`, `current`) VALUES (1,2,'01','1990','12','2015','kristin fellows photography','Asheville','North Carolina','828-335-6525','freelance photographer','photojournalism ','(ongoing)','portfolio at kristinfellowsphotography.smugmug.com','Contract',''),(2,1,'04','2013','01','2015','Pizza Hut','Leicester','North Carolina','828-254-8388','Driver','Delivering food\r\nDishwashing\r\nCustomer service','School in Denmark','','Food',''),(7,1,'09','2015','12','2015','ACE Hardware','Asheville','North Carolina','828-505-3672','Cashier','Running the register\r\nAssisting customers\r\nForwarding calls','','','Retail','y'),(5,1,'09','2013','05','2014','Roots Hummus','Asheville','North Carolina','828-232-2828','Dishwasher','Washing dishes\r\nFood prep\r\nPackaging','Overworked and stressed out','','Food',''),(8,7,'05','2015','11','2015','ChiLA','Chicago','Illinois','310-985-1028','Assistant property manager ','Coordinate maintenance, Collect rent.','Relocated to North Carolina.','','Other','n');
/*!40000 ALTER TABLE `WorkersJobHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkersSchoolHistory`
--

DROP TABLE IF EXISTS `WorkersSchoolHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkersSchoolHistory` (
  `schoolExperienceID` int(11) NOT NULL AUTO_INCREMENT,
  `workerID` int(11) NOT NULL,
  `schoolName` varchar(100) NOT NULL,
  `fromMonth` varchar(2) NOT NULL,
  `fromYear` varchar(4) NOT NULL,
  `toMonth` varchar(2) NOT NULL,
  `toYear` varchar(4) NOT NULL,
  `genre` varchar(30) NOT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(33) NOT NULL,
  `country` varchar(85) NOT NULL,
  `major` varchar(100) NOT NULL,
  `current` varchar(1) NOT NULL,
  PRIMARY KEY (`schoolExperienceID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkersSchoolHistory`
--

LOCK TABLES `WorkersSchoolHistory` WRITE;
/*!40000 ALTER TABLE `WorkersSchoolHistory` DISABLE KEYS */;
INSERT INTO `WorkersSchoolHistory` (`schoolExperienceID`, `workerID`, `schoolName`, `fromMonth`, `fromYear`, `toMonth`, `toYear`, `genre`, `city`, `state`, `country`, `major`, `current`) VALUES (1,2,'ACS International ','09','1973','06','1974','High School','London','International','UK','college prep',''),(2,2,'Gettysburg College','09','1974','05','1978','College','Gettysburg','Pennsylvania','','Psychology and Art',''),(3,2,'Univ of North Carolina, Asheville','01','2006','04','2006','University','Asheville','North Carolina','','Great Smokies Writing Program',''),(4,7,'Florida Air Academy','08','2012','05','2015','High School','Melbourne ','Florida','','','n');
/*!40000 ALTER TABLE `WorkersSchoolHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'JobPool'
--

--
-- Dumping routines for database 'JobPool'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-19 15:55:06
